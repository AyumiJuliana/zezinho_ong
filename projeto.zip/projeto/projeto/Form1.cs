﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using Npgsql;


namespace projeto
{
    public partial class Form1 : Form
    {
        NpgsqlConnection conexao;

        public Form1()
        {
            InitializeComponent();

            conexao = new NpgsqlConnection(
                connectionString: "Server=localhost;" +
                "Port=5432;" +
                "User ID=postgres;" +
                "Password=postgres;" +
                "Database=AnimaisONG;" +
                "Pooling=true;");
            ExecutarComandoDB("SELECT * FROM adocao;");

            PreencherListaAnimal();//preencher o CblAnimais com a lista deanimais
            PreencherListaAdotante();//
        }

        private void TsmiAnimal_Click(object sender, EventArgs e)
        {
            FrmAnimal frmAnimal = new FrmAnimal();
            frmAnimal.ShowDialog(); //show dialog trava o form anterior
        }

        private void TsmiAdotante_Click(object sender, EventArgs e)
        {
            FrmAdotante frmAdotante = new FrmAdotante();
            frmAdotante.ShowDialog();
        }

        private void TsmiAjuda_Click(object sender, EventArgs e)
        {
            FrmAjuda frmAjuda = new FrmAjuda();
            frmAjuda.ShowDialog();
        }
        private void ExecutarComandoDB(String query)
        {
            try{
                //this.conexao.Open();

                //var query = "SELECT * FROM adotante;";

                using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(query, conexao))
                {
                    using (DataTable dt = new DataTable())
                    {
                        da.Fill(dt);
                        DtgAdocao.DataSource = dt;
                    }
                };

                //this.conexao.Close();//fechando a conexao
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show("erro: " + ex.Message);
            }
        }
        private void BtnBusca_Click(object sender, EventArgs e)
        {
            string busca = this.TxtBusca.Text;

            string query = "SELECT an.nome AS animal, an.tipo," +
                          "as.nome AS adotante, ac.data_adocao," +
                          "ac.status, ac.informacoes FROM adocao AS ac" +
                          "INNER JOIN animal AS an ON ac.animal = ac.id" +
                          "INNER JOIN adotante AS ad ON ac.adotante = ad.id" +
                          $"WHERE ad.nome LIKE '%{busca}%' or an.nome LIKE '%{busca}%';";


            ExecutarComandoDB(query);

        }
        private void NovoAdotante()
        {
            if(!string.IsNullOrEmpty(this.TxtBusca.Text)&&
                !string.IsNullOrEmpty(this.CblAdotante.Text)&&
                !string.IsNullOrEmpty(this.TxtInformacoes.Text)&&
                !string.IsNullOrEmpty(this.TxtStatus.Text))
                { 
                    int animal = int.Parse(this.CblAnimal.Text);
                    int adotante = int.Parse(this.CblAdotante.Text);
                    string situacao = this.TxtStatus.Text;
                    string informacoes = this.TxtInformacoes.Text;
                    DateTime dataAtual = DateTime.Now;


                    string query = "INSERT INTO adocao(animal,adotante, status, informacoes, data_adocao)" +
                           $"VALUES ({animal},{adotante}, {situacao}, {informacoes});";

                    ExecutarComandoDB(query);
                    ExecutarComandoDB("SELECT * FROM adocao");
            }
            else
            {
                MessageBox.Show("Campos obrigatorios nao preenchidos!!");

            }
        }
        //I - Interface
        //Lista Animais
        private IEnumerable <Animal> ListaAnimal()
        {
            try
            {
                var query = "SELECT nome FROM animal;";

                using (conexao)
                {
                    //IEnumerable <Animal> animais = conexao.Query<Animal>(query);
                    return conexao.Query<Animal>(sql: query);
                }

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("erro: " + ex.Message);
                return Enumerable.Empty<Animal>();
            }
        }

        private void PreencherListaAnimal()
        {
            foreach (var animal in ListaAnimal())
            {
                this.CblAnimal.Items.Add(animal.Nome);
            }
        }



        //Lista Adotante
        private IEnumerable<Adotante> ListaAdotante()
        {
            try
            {
                var query = "SELECT nome FROM adotante;";

                using (conexao)
                {
                    //IEnumerable <Animal> animais = conexao.Query<Animal>(query);
                    return conexao.Query<Adotante>(sql: query);

                    var teste 
            foreach (var animal in ListaAdotante())
            {
                this.CblAnimal.Items.Add(adotante.Nome);
            }
                }

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("erro: " + ex.Message);
                return Enumerable.Empty<Adotante>();
            }
        }

        private void PreencherListaAdotante()
        {
        }




        private void BtnNovaAdocao_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblAnimal.Text)&&
                !string.IsNullOrEmpty(CblAdotante.Text)&&
                !string.IsNullOrEmpty(TxtStatus.Text)&&
                !string.IsNullOrEmpty(TxtInformacoes.Text))

            {
            NovoAdotante();

            }
            else { 
                MessageBox.Show("Campos obrigatorios nao preenchidos!!!");
                if (string.IsNullOrEmpty(this.CblAnimal.Text))
                    LblAnimal.Font=new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(this.CblAdotante.Text))
                    LblAdotante.Font = new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(this.TxtStatus.Text))
                    LblStatus.Font = new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(this.TxtInformacoes.Text))
                    LblInformacoes.Font = new Font(this.Font, FontStyle.Bold);
            }
            
        }
    }
}
