﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projeto
{
    internal class Animal
    {
        //a tabela animal se tornou classe - depper - mapeamento
        public int Id { get; set; }
        public string Nome { get; set; }

        public string Genero { get; set; }
        public DateTime DataNascimento { get; set; }
        public Boolean DisponibilidadeAdoca { get; set; }
        public string Tipo { get; set; }
        public string Vacinacao { get; set; }
        public string Status { get; set; }


        public Animal()
        {

        }
    }
}
