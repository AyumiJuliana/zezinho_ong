﻿namespace projeto
{
    partial class FrmAdotante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LblGenero = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.TxtGenero = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnNovaAnimal = new System.Windows.Forms.Button();
            this.LblInformacoes = new System.Windows.Forms.Label();
            this.LblAnimal = new System.Windows.Forms.Label();
            this.LblTipoAnimal = new System.Windows.Forms.Label();
            this.LblNomeAnimal = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.TxtAnimal = new System.Windows.Forms.TextBox();
            this.TxtRG = new System.Windows.Forms.TextBox();
            this.TxtNomeAdotante = new System.Windows.Forms.TextBox();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgAdotante = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtCPF = new System.Windows.Forms.TextBox();
            this.BtnBusca = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdotante)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(532, 61);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 62;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(529, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 16);
            this.label2.TabIndex = 61;
            this.label2.Text = "Data de Nascimento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(181, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 16);
            this.label1.TabIndex = 60;
            this.label1.Text = "Cidade:";
            // 
            // LblGenero
            // 
            this.LblGenero.AutoSize = true;
            this.LblGenero.Location = new System.Drawing.Point(11, 108);
            this.LblGenero.Name = "LblGenero";
            this.LblGenero.Size = new System.Drawing.Size(69, 16);
            this.LblGenero.TabIndex = 59;
            this.LblGenero.Text = "Endereço:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(184, 127);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 58;
            // 
            // TxtGenero
            // 
            this.TxtGenero.Location = new System.Drawing.Point(14, 127);
            this.TxtGenero.Name = "TxtGenero";
            this.TxtGenero.Size = new System.Drawing.Size(100, 22);
            this.TxtGenero.TabIndex = 57;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Khaki;
            this.button3.Location = new System.Drawing.Point(341, 161);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 45);
            this.button3.TabIndex = 56;
            this.button3.Text = "Cancelar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.Location = new System.Drawing.Point(232, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 45);
            this.button2.TabIndex = 55;
            this.button2.Text = "Excluir";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.Location = new System.Drawing.Point(123, 161);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 45);
            this.button1.TabIndex = 54;
            this.button1.Text = "Editar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // BtnNovaAnimal
            // 
            this.BtnNovaAnimal.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnNovaAnimal.Location = new System.Drawing.Point(14, 161);
            this.BtnNovaAnimal.Name = "BtnNovaAnimal";
            this.BtnNovaAnimal.Size = new System.Drawing.Size(103, 45);
            this.BtnNovaAnimal.TabIndex = 53;
            this.BtnNovaAnimal.Text = "Novo Adotante";
            this.BtnNovaAnimal.UseVisualStyleBackColor = false;
            // 
            // LblInformacoes
            // 
            this.LblInformacoes.AutoSize = true;
            this.LblInformacoes.Location = new System.Drawing.Point(529, 108);
            this.LblInformacoes.Name = "LblInformacoes";
            this.LblInformacoes.Size = new System.Drawing.Size(64, 16);
            this.LblInformacoes.TabIndex = 52;
            this.LblInformacoes.Text = "Telefone:";
            // 
            // LblAnimal
            // 
            this.LblAnimal.AutoSize = true;
            this.LblAnimal.Location = new System.Drawing.Point(350, 108);
            this.LblAnimal.Name = "LblAnimal";
            this.LblAnimal.Size = new System.Drawing.Size(53, 16);
            this.LblAnimal.TabIndex = 51;
            this.LblAnimal.Text = "Estado:";
            // 
            // LblTipoAnimal
            // 
            this.LblTipoAnimal.AutoSize = true;
            this.LblTipoAnimal.Location = new System.Drawing.Point(181, 44);
            this.LblTipoAnimal.Name = "LblTipoAnimal";
            this.LblTipoAnimal.Size = new System.Drawing.Size(30, 16);
            this.LblTipoAnimal.TabIndex = 50;
            this.LblTipoAnimal.Text = "RG:";
            // 
            // LblNomeAnimal
            // 
            this.LblNomeAnimal.AutoSize = true;
            this.LblNomeAnimal.Location = new System.Drawing.Point(14, 44);
            this.LblNomeAnimal.Name = "LblNomeAnimal";
            this.LblNomeAnimal.Size = new System.Drawing.Size(47, 16);
            this.LblNomeAnimal.TabIndex = 49;
            this.LblNomeAnimal.Text = "Nome:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(532, 127);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 48;
            // 
            // TxtAnimal
            // 
            this.TxtAnimal.Location = new System.Drawing.Point(353, 127);
            this.TxtAnimal.Name = "TxtAnimal";
            this.TxtAnimal.Size = new System.Drawing.Size(100, 22);
            this.TxtAnimal.TabIndex = 47;
            // 
            // TxtRG
            // 
            this.TxtRG.Location = new System.Drawing.Point(184, 63);
            this.TxtRG.Name = "TxtRG";
            this.TxtRG.Size = new System.Drawing.Size(151, 22);
            this.TxtRG.TabIndex = 46;
            // 
            // TxtNomeAdotante
            // 
            this.TxtNomeAdotante.Location = new System.Drawing.Point(15, 63);
            this.TxtNomeAdotante.Name = "TxtNomeAdotante";
            this.TxtNomeAdotante.Size = new System.Drawing.Size(151, 22);
            this.TxtNomeAdotante.TabIndex = 45;
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(14, 232);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(75, 16);
            this.LblBusca.TabIndex = 44;
            this.LblBusca.Text = "Buscar por:";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(95, 229);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(306, 22);
            this.TxtBusca.TabIndex = 42;
            // 
            // DtgAdotante
            // 
            this.DtgAdotante.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAdotante.Location = new System.Drawing.Point(14, 257);
            this.DtgAdotante.Name = "DtgAdotante";
            this.DtgAdotante.RowHeadersWidth = 51;
            this.DtgAdotante.RowTemplate.Height = 24;
            this.DtgAdotante.Size = new System.Drawing.Size(776, 150);
            this.DtgAdotante.TabIndex = 41;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(350, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 64;
            this.label3.Text = "CPF:";
            // 
            // TxtCPF
            // 
            this.TxtCPF.Location = new System.Drawing.Point(353, 63);
            this.TxtCPF.Name = "TxtCPF";
            this.TxtCPF.Size = new System.Drawing.Size(151, 22);
            this.TxtCPF.TabIndex = 63;
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackColor = System.Drawing.Color.Transparent;
            this.BtnBusca.BackgroundImage = global::projeto.Properties.Resources.search;
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnBusca.ImageKey = "(nenhum/a)";
            this.BtnBusca.Location = new System.Drawing.Point(408, 229);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(37, 23);
            this.BtnBusca.TabIndex = 43;
            this.BtnBusca.UseVisualStyleBackColor = false;
            // 
            // FrmAdotante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtCPF);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblGenero);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.TxtGenero);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnNovaAnimal);
            this.Controls.Add(this.LblInformacoes);
            this.Controls.Add(this.LblAnimal);
            this.Controls.Add(this.LblTipoAnimal);
            this.Controls.Add(this.LblNomeAnimal);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.TxtAnimal);
            this.Controls.Add(this.TxtRG);
            this.Controls.Add(this.TxtNomeAdotante);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAdotante);
            this.Name = "FrmAdotante";
            this.Text = "FrmAdotante";
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdotante)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblGenero;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox TxtGenero;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtnNovaAnimal;
        private System.Windows.Forms.Label LblInformacoes;
        private System.Windows.Forms.Label LblAnimal;
        private System.Windows.Forms.Label LblTipoAnimal;
        private System.Windows.Forms.Label LblNomeAnimal;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox TxtAnimal;
        private System.Windows.Forms.TextBox TxtRG;
        private System.Windows.Forms.TextBox TxtNomeAdotante;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.Button BtnBusca;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.DataGridView DtgAdotante;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtCPF;
    }
}