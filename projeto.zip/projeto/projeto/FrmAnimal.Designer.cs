﻿namespace projeto
{
    partial class FrmAnimal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnNovaAnimal = new System.Windows.Forms.Button();
            this.LblInformacoes = new System.Windows.Forms.Label();
            this.LblAnimal = new System.Windows.Forms.Label();
            this.LblTipoAnimal = new System.Windows.Forms.Label();
            this.LblNomeAnimal = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.TxtAnimal = new System.Windows.Forms.TextBox();
            this.TxtTipoAnimal = new System.Windows.Forms.TextBox();
            this.TxtNomeAnimal = new System.Windows.Forms.TextBox();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgAnimal = new System.Windows.Forms.DataGridView();
            this.BtnBusca = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LblGenero = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.TxtGenero = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimal)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Khaki;
            this.button3.Location = new System.Drawing.Point(339, 161);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 45);
            this.button3.TabIndex = 33;
            this.button3.Text = "Cancelar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.Location = new System.Drawing.Point(230, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 45);
            this.button2.TabIndex = 32;
            this.button2.Text = "Excluir";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.Location = new System.Drawing.Point(121, 161);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 45);
            this.button1.TabIndex = 31;
            this.button1.Text = "Editar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // BtnNovaAnimal
            // 
            this.BtnNovaAnimal.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnNovaAnimal.Location = new System.Drawing.Point(12, 161);
            this.BtnNovaAnimal.Name = "BtnNovaAnimal";
            this.BtnNovaAnimal.Size = new System.Drawing.Size(103, 45);
            this.BtnNovaAnimal.TabIndex = 30;
            this.BtnNovaAnimal.Text = "Nova Animal";
            this.BtnNovaAnimal.UseVisualStyleBackColor = false;
            // 
            // LblInformacoes
            // 
            this.LblInformacoes.AutoSize = true;
            this.LblInformacoes.Location = new System.Drawing.Point(548, 114);
            this.LblInformacoes.Name = "LblInformacoes";
            this.LblInformacoes.Size = new System.Drawing.Size(156, 16);
            this.LblInformacoes.TabIndex = 29;
            this.LblInformacoes.Text = "Disponivel para Adoção:";
            // 
            // LblAnimal
            // 
            this.LblAnimal.AutoSize = true;
            this.LblAnimal.Location = new System.Drawing.Point(359, 114);
            this.LblAnimal.Name = "LblAnimal";
            this.LblAnimal.Size = new System.Drawing.Size(125, 16);
            this.LblAnimal.TabIndex = 28;
            this.LblAnimal.Text = "Situação do animal:";
            // 
            // LblTipoAnimal
            // 
            this.LblTipoAnimal.AutoSize = true;
            this.LblTipoAnimal.Location = new System.Drawing.Point(198, 44);
            this.LblTipoAnimal.Name = "LblTipoAnimal";
            this.LblTipoAnimal.Size = new System.Drawing.Size(101, 16);
            this.LblTipoAnimal.TabIndex = 27;
            this.LblTipoAnimal.Text = "Tipo do Animal:";
            // 
            // LblNomeAnimal
            // 
            this.LblNomeAnimal.AutoSize = true;
            this.LblNomeAnimal.Location = new System.Drawing.Point(12, 44);
            this.LblNomeAnimal.Name = "LblNomeAnimal";
            this.LblNomeAnimal.Size = new System.Drawing.Size(109, 16);
            this.LblNomeAnimal.TabIndex = 26;
            this.LblNomeAnimal.Text = "Nome do animal:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(551, 133);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 25;
            // 
            // TxtAnimal
            // 
            this.TxtAnimal.Location = new System.Drawing.Point(362, 133);
            this.TxtAnimal.Name = "TxtAnimal";
            this.TxtAnimal.Size = new System.Drawing.Size(100, 22);
            this.TxtAnimal.TabIndex = 24;
            // 
            // TxtTipoAnimal
            // 
            this.TxtTipoAnimal.Location = new System.Drawing.Point(201, 63);
            this.TxtTipoAnimal.Name = "TxtTipoAnimal";
            this.TxtTipoAnimal.Size = new System.Drawing.Size(151, 22);
            this.TxtTipoAnimal.TabIndex = 23;
            // 
            // TxtNomeAnimal
            // 
            this.TxtNomeAnimal.Location = new System.Drawing.Point(13, 63);
            this.TxtNomeAnimal.Name = "TxtNomeAnimal";
            this.TxtNomeAnimal.Size = new System.Drawing.Size(151, 22);
            this.TxtNomeAnimal.TabIndex = 22;
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(12, 232);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(75, 16);
            this.LblBusca.TabIndex = 21;
            this.LblBusca.Text = "Buscar por:";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(93, 229);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(306, 22);
            this.TxtBusca.TabIndex = 19;
            // 
            // DtgAnimal
            // 
            this.DtgAnimal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAnimal.Location = new System.Drawing.Point(12, 257);
            this.DtgAnimal.Name = "DtgAnimal";
            this.DtgAnimal.RowHeadersWidth = 51;
            this.DtgAnimal.RowTemplate.Height = 24;
            this.DtgAnimal.Size = new System.Drawing.Size(776, 150);
            this.DtgAnimal.TabIndex = 18;
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackColor = System.Drawing.Color.Transparent;
            this.BtnBusca.BackgroundImage = global::projeto.Properties.Resources.search;
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnBusca.ImageKey = "(nenhum/a)";
            this.BtnBusca.Location = new System.Drawing.Point(406, 229);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(37, 23);
            this.BtnBusca.TabIndex = 20;
            this.BtnBusca.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(198, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 37;
            this.label1.Text = "Variação:";
            // 
            // LblGenero
            // 
            this.LblGenero.AutoSize = true;
            this.LblGenero.Location = new System.Drawing.Point(9, 114);
            this.LblGenero.Name = "LblGenero";
            this.LblGenero.Size = new System.Drawing.Size(55, 16);
            this.LblGenero.TabIndex = 36;
            this.LblGenero.Text = "Gênero:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(201, 133);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 35;
            // 
            // TxtGenero
            // 
            this.TxtGenero.Location = new System.Drawing.Point(12, 133);
            this.TxtGenero.Name = "TxtGenero";
            this.TxtGenero.Size = new System.Drawing.Size(100, 22);
            this.TxtGenero.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(403, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 16);
            this.label2.TabIndex = 39;
            this.label2.Text = "Data de Nascimento:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(406, 63);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 40;
            // 
            // FrmAnimal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblGenero);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.TxtGenero);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnNovaAnimal);
            this.Controls.Add(this.LblInformacoes);
            this.Controls.Add(this.LblAnimal);
            this.Controls.Add(this.LblTipoAnimal);
            this.Controls.Add(this.LblNomeAnimal);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.TxtAnimal);
            this.Controls.Add(this.TxtTipoAnimal);
            this.Controls.Add(this.TxtNomeAnimal);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAnimal);
            this.Name = "FrmAnimal";
            this.Text = "FrmAnimal";
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtnNovaAnimal;
        private System.Windows.Forms.Label LblInformacoes;
        private System.Windows.Forms.Label LblAnimal;
        private System.Windows.Forms.Label LblTipoAnimal;
        private System.Windows.Forms.Label LblNomeAnimal;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox TxtAnimal;
        private System.Windows.Forms.TextBox TxtTipoAnimal;
        private System.Windows.Forms.TextBox TxtNomeAnimal;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.Button BtnBusca;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.DataGridView DtgAnimal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblGenero;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox TxtGenero;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}