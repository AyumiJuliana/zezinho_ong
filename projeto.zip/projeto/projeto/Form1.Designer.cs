﻿namespace projeto
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuPrincipal = new System.Windows.Forms.MenuStrip();
            this.TsmCadastro = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAnimal = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAdotante = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.StrpRodape = new System.Windows.Forms.StatusStrip();
            this.DtgAdocao = new System.Windows.Forms.DataGridView();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.BtnBusca = new System.Windows.Forms.Button();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtStatus = new System.Windows.Forms.TextBox();
            this.TxtInformacoes = new System.Windows.Forms.TextBox();
            this.LblAdotante = new System.Windows.Forms.Label();
            this.LblStatus = new System.Windows.Forms.Label();
            this.LblAnimal = new System.Windows.Forms.Label();
            this.LblInformacoes = new System.Windows.Forms.Label();
            this.BtnNovaAdocao = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.CblAnimal = new System.Windows.Forms.ComboBox();
            this.CblAdotante = new System.Windows.Forms.ComboBox();
            this.MenuPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdocao)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuPrincipal
            // 
            this.MenuPrincipal.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MenuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmCadastro,
            this.TsmAjuda});
            this.MenuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.MenuPrincipal.Name = "MenuPrincipal";
            this.MenuPrincipal.Size = new System.Drawing.Size(800, 28);
            this.MenuPrincipal.TabIndex = 0;
            this.MenuPrincipal.Text = "menuStrip1";
            // 
            // TsmCadastro
            // 
            this.TsmCadastro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmiAnimal,
            this.TsmiAdotante});
            this.TsmCadastro.Name = "TsmCadastro";
            this.TsmCadastro.Size = new System.Drawing.Size(82, 24);
            this.TsmCadastro.Text = "Cadastro";
            // 
            // TsmiAnimal
            // 
            this.TsmiAnimal.Name = "TsmiAnimal";
            this.TsmiAnimal.Size = new System.Drawing.Size(154, 26);
            this.TsmiAnimal.Text = "Animal";
            this.TsmiAnimal.Click += new System.EventHandler(this.TsmiAnimal_Click);
            // 
            // TsmiAdotante
            // 
            this.TsmiAdotante.Name = "TsmiAdotante";
            this.TsmiAdotante.Size = new System.Drawing.Size(154, 26);
            this.TsmiAdotante.Text = "Adotante";
            this.TsmiAdotante.Click += new System.EventHandler(this.TsmiAdotante_Click);
            // 
            // TsmAjuda
            // 
            this.TsmAjuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmiAjuda});
            this.TsmAjuda.Name = "TsmAjuda";
            this.TsmAjuda.Size = new System.Drawing.Size(62, 24);
            this.TsmAjuda.Text = "Ajuda";
            // 
            // TsmiAjuda
            // 
            this.TsmiAjuda.Name = "TsmiAjuda";
            this.TsmiAjuda.Size = new System.Drawing.Size(131, 26);
            this.TsmiAjuda.Text = "Ajuda";
            this.TsmiAjuda.Click += new System.EventHandler(this.TsmiAjuda_Click);
            // 
            // StrpRodape
            // 
            this.StrpRodape.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.StrpRodape.Location = new System.Drawing.Point(0, 428);
            this.StrpRodape.Name = "StrpRodape";
            this.StrpRodape.Size = new System.Drawing.Size(800, 22);
            this.StrpRodape.TabIndex = 1;
            this.StrpRodape.Text = "statusStrip1";
            // 
            // DtgAdocao
            // 
            this.DtgAdocao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAdocao.Location = new System.Drawing.Point(12, 275);
            this.DtgAdocao.Name = "DtgAdocao";
            this.DtgAdocao.RowHeadersWidth = 51;
            this.DtgAdocao.RowTemplate.Height = 24;
            this.DtgAdocao.Size = new System.Drawing.Size(776, 150);
            this.DtgAdocao.TabIndex = 2;
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(93, 247);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(306, 22);
            this.TxtBusca.TabIndex = 3;
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackColor = System.Drawing.Color.Transparent;
            this.BtnBusca.BackgroundImage = global::projeto.Properties.Resources.search;
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnBusca.ImageKey = "(nenhum/a)";
            this.BtnBusca.Location = new System.Drawing.Point(406, 247);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(37, 23);
            this.BtnBusca.TabIndex = 4;
            this.BtnBusca.UseVisualStyleBackColor = false;
            this.BtnBusca.Click += new System.EventHandler(this.BtnBusca_Click);
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(12, 250);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(75, 16);
            this.LblBusca.TabIndex = 5;
            this.LblBusca.Text = "Buscar por:";
            // 
            // TxtStatus
            // 
            this.TxtStatus.Location = new System.Drawing.Point(201, 81);
            this.TxtStatus.Name = "TxtStatus";
            this.TxtStatus.Size = new System.Drawing.Size(151, 22);
            this.TxtStatus.TabIndex = 7;
            // 
            // TxtInformacoes
            // 
            this.TxtInformacoes.Location = new System.Drawing.Point(610, 81);
            this.TxtInformacoes.Name = "TxtInformacoes";
            this.TxtInformacoes.Size = new System.Drawing.Size(100, 22);
            this.TxtInformacoes.TabIndex = 9;
            // 
            // LblAdotante
            // 
            this.LblAdotante.AutoSize = true;
            this.LblAdotante.Location = new System.Drawing.Point(12, 62);
            this.LblAdotante.Name = "LblAdotante";
            this.LblAdotante.Size = new System.Drawing.Size(128, 16);
            this.LblAdotante.TabIndex = 10;
            this.LblAdotante.Text = "Pessoa que adotou:";
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = true;
            this.LblStatus.Location = new System.Drawing.Point(198, 62);
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.Size = new System.Drawing.Size(133, 16);
            this.LblStatus.TabIndex = 11;
            this.LblStatus.Text = "Situação da Adoção:";
            // 
            // LblAnimal
            // 
            this.LblAnimal.AutoSize = true;
            this.LblAnimal.Location = new System.Drawing.Point(418, 62);
            this.LblAnimal.Name = "LblAnimal";
            this.LblAnimal.Size = new System.Drawing.Size(51, 16);
            this.LblAnimal.TabIndex = 12;
            this.LblAnimal.Text = "Animal:";
            // 
            // LblInformacoes
            // 
            this.LblInformacoes.AutoSize = true;
            this.LblInformacoes.Location = new System.Drawing.Point(607, 62);
            this.LblInformacoes.Name = "LblInformacoes";
            this.LblInformacoes.Size = new System.Drawing.Size(84, 16);
            this.LblInformacoes.TabIndex = 13;
            this.LblInformacoes.Text = "Informações:";
            // 
            // BtnNovaAdocao
            // 
            this.BtnNovaAdocao.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnNovaAdocao.Location = new System.Drawing.Point(15, 127);
            this.BtnNovaAdocao.Name = "BtnNovaAdocao";
            this.BtnNovaAdocao.Size = new System.Drawing.Size(103, 45);
            this.BtnNovaAdocao.TabIndex = 14;
            this.BtnNovaAdocao.Text = "Nova Adoção";
            this.BtnNovaAdocao.UseVisualStyleBackColor = false;
            this.BtnNovaAdocao.Click += new System.EventHandler(this.BtnNovaAdocao_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.Location = new System.Drawing.Point(124, 127);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 45);
            this.button1.TabIndex = 15;
            this.button1.Text = "Editar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.Location = new System.Drawing.Point(233, 127);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 45);
            this.button2.TabIndex = 16;
            this.button2.Text = "Excluir";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Khaki;
            this.button3.Location = new System.Drawing.Point(342, 127);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 45);
            this.button3.TabIndex = 17;
            this.button3.Text = "Cancelar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            // 
            // CblAnimal
            // 
            this.CblAnimal.FormattingEnabled = true;
            this.CblAnimal.Location = new System.Drawing.Point(421, 79);
            this.CblAnimal.Name = "CblAnimal";
            this.CblAnimal.Size = new System.Drawing.Size(121, 24);
            this.CblAnimal.TabIndex = 18;
            // 
            // CblAdotante
            // 
            this.CblAdotante.FormattingEnabled = true;
            this.CblAdotante.Location = new System.Drawing.Point(15, 81);
            this.CblAdotante.Name = "CblAdotante";
            this.CblAdotante.Size = new System.Drawing.Size(121, 24);
            this.CblAdotante.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CblAdotante);
            this.Controls.Add(this.CblAnimal);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnNovaAdocao);
            this.Controls.Add(this.LblInformacoes);
            this.Controls.Add(this.LblAnimal);
            this.Controls.Add(this.LblStatus);
            this.Controls.Add(this.LblAdotante);
            this.Controls.Add(this.TxtInformacoes);
            this.Controls.Add(this.TxtStatus);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAdocao);
            this.Controls.Add(this.StrpRodape);
            this.Controls.Add(this.MenuPrincipal);
            this.MainMenuStrip = this.MenuPrincipal;
            this.Name = "Form1";
            this.Text = "Form1";
            this.MenuPrincipal.ResumeLayout(false);
            this.MenuPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdocao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem TsmCadastro;
        private System.Windows.Forms.ToolStripMenuItem TsmiAnimal;
        private System.Windows.Forms.ToolStripMenuItem TsmiAdotante;
        private System.Windows.Forms.ToolStripMenuItem TsmAjuda;
        private System.Windows.Forms.ToolStripMenuItem TsmiAjuda;
        private System.Windows.Forms.StatusStrip StrpRodape;
        private System.Windows.Forms.DataGridView DtgAdocao;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.Button BtnBusca;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.TextBox TxtStatus;
        private System.Windows.Forms.TextBox TxtInformacoes;
        private System.Windows.Forms.Label LblAdotante;
        private System.Windows.Forms.Label LblStatus;
        private System.Windows.Forms.Label LblAnimal;
        private System.Windows.Forms.Label LblInformacoes;
        private System.Windows.Forms.Button BtnNovaAdocao;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox CblAnimal;
        private System.Windows.Forms.ComboBox CblAdotante;
    }
}

