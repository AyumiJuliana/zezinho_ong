﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class FrmAjuda : Form
    {
        public FrmAjuda()
        {
            InitializeComponent();
        }

        private void FrmAjuda_Load(object sender, EventArgs e)
        {
            this.LblAjuda.Text = "Aplicação: ONG Pet\n\n" +
                                 "Versão: 0.0\n\n" +
                                 "Desenvolvimento: INI2B\n\n" +
                                 "Projeto desenvolvimento como apoio \n" +
                                 "a disciplina de Linguagem de programação 2 (C#)";
        }
    }
}
